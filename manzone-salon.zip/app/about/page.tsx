import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Scissors, Users, Award, Clock, MapPin, Phone, Mail } from "lucide-react"
import { Header } from "@/components/navigation/header"
import { Footer } from "@/components/footer"

export default function AboutPage() {
  const stats = [
    { label: "Years of Experience", value: "10+", icon: Award },
    { label: "Happy Customers", value: "5000+", icon: Users },
    { label: "Expert Stylists", value: "15+", icon: Scissors },
    { label: "Services Offered", value: "25+", icon: Clock },
  ]

  const values = [
    {
      title: "Quality First",
      description: "We use only premium products and maintain the highest standards in every service.",
    },
    {
      title: "Expert Team",
      description: "Our stylists are trained professionals with years of experience in men's grooming.",
    },
    {
      title: "Customer Focus",
      description: "Your satisfaction is our priority. We listen to your needs and deliver accordingly.",
    },
    {
      title: "Modern Techniques",
      description: "We stay updated with the latest trends and techniques in men's styling and grooming.",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-card to-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="secondary" className="mb-4">
              About MANZONE
            </Badge>
            <h1 className="text-4xl md:text-6xl font-serif font-bold text-foreground mb-6 text-balance">
              Crafting Style Since <span className="text-primary">2014</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 text-pretty max-w-3xl mx-auto">
              MANZONE has been Delhi NCR's premier destination for men's grooming, combining traditional barbering
              techniques with modern styling to create the perfect look for every gentleman.
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 mx-auto mb-2 bg-primary/10 rounded-full flex items-center justify-center">
                    <stat.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-2xl md:text-3xl font-bold">{stat.value}</CardTitle>
                  <CardDescription className="text-sm">{stat.label}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16 bg-card/30">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-serif font-bold mb-6">Our Story</h2>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    Founded in 2014 by master barber Rajesh Kumar, MANZONE began as a small neighborhood barbershop with
                    a vision to elevate men's grooming standards in Delhi NCR.
                  </p>
                  <p>
                    What started as a passion project has grown into a premium grooming destination, serving thousands
                    of satisfied customers who trust us with their style and appearance.
                  </p>
                  <p>
                    Today, MANZONE combines the artistry of traditional barbering with modern techniques and premium
                    products to deliver an unmatched grooming experience.
                  </p>
                </div>
              </div>
              <div className="aspect-[4/3] rounded-lg overflow-hidden">
                <img src="/modern-barbershop.png" alt="MANZONE Interior" className="w-full h-full object-cover" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">Our Values</h2>
              <p className="text-lg text-muted-foreground">The principles that guide everything we do at MANZONE</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {values.map((value, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="text-xl">{value.title}</CardTitle>
                    <CardDescription className="text-base">{value.description}</CardDescription>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Info */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-8">Visit Our Salon</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="flex flex-col items-center">
                <MapPin className="h-8 w-8 mb-4 opacity-90" />
                <h3 className="font-semibold mb-2">Location</h3>
                <p className="opacity-90">Connaught Place, New Delhi, 110001</p>
              </div>
              <div className="flex flex-col items-center">
                <Phone className="h-8 w-8 mb-4 opacity-90" />
                <h3 className="font-semibold mb-2">Phone</h3>
                <p className="opacity-90">+91 98765 43210</p>
              </div>
              <div className="flex flex-col items-center">
                <Mail className="h-8 w-8 mb-4 opacity-90" />
                <h3 className="font-semibold mb-2">Email</h3>
                <p className="opacity-90">info@manzone.com</p>
              </div>
            </div>
            <Button size="lg" variant="secondary" className="mt-8">
              Book Your Appointment
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
