import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, Star, Calendar } from "lucide-react"
import { Header } from "@/components/navigation/header"
import Link from "next/link"

export default function ServicesPage() {
  const services = [
    {
      id: 1,
      name: "Premium Haircut",
      description: "Professional styling with consultation and premium products. Includes wash, cut, and styling.",
      price: "₹800",
      duration: "45 min",
      image: "/placeholder-mbvn4.png",
      features: ["Hair wash", "Professional cut", "Styling", "Hair treatment"],
      popular: true,
    },
    {
      id: 2,
      name: "Beard Styling",
      description: "Expert beard trimming, shaping, and grooming with premium oils and balms.",
      price: "₹500",
      duration: "30 min",
      image: "/placeholder-w6mch.png",
      features: ["Beard trim", "Shape & style", "Beard oil", "Aftercare advice"],
      popular: false,
    },
    {
      id: 3,
      name: "Facial Treatment",
      description: "Deep cleansing facial with extraction, mask, and moisturizing for healthy skin.",
      price: "₹1200",
      duration: "60 min",
      image: "/placeholder-4lakq.png",
      features: ["Deep cleansing", "Extraction", "Face mask", "Moisturizing"],
      popular: false,
    },
    {
      id: 4,
      name: "Complete Grooming",
      description: "Full grooming package including haircut, beard styling, and facial treatment.",
      price: "₹2000",
      duration: "90 min",
      image: "/placeholder-huelz.png",
      features: ["Premium haircut", "Beard styling", "Facial treatment", "Hair wash"],
      popular: true,
    },
    {
      id: 5,
      name: "Hair Wash & Blow Dry",
      description: "Professional hair wash with premium shampoo and expert blow dry styling.",
      price: "₹300",
      duration: "20 min",
      image: "/placeholder-mbvn4.png",
      features: ["Premium shampoo", "Scalp massage", "Blow dry", "Basic styling"],
      popular: false,
    },
    {
      id: 6,
      name: "Mustache Styling",
      description: "Precision mustache trimming and styling for the perfect look.",
      price: "₹200",
      duration: "15 min",
      image: "/placeholder-w6mch.png",
      features: ["Precision trim", "Shape styling", "Wax application", "Grooming tips"],
      popular: false,
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-card to-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="secondary" className="mb-4">
              Our Services
            </Badge>
            <h1 className="text-4xl md:text-6xl font-serif font-bold text-foreground mb-6 text-balance">
              Premium <span className="text-primary">Grooming</span> Services
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 text-pretty max-w-2xl mx-auto">
              Discover our comprehensive range of professional grooming services designed for the modern gentleman.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {services.map((service) => (
              <Card
                key={service.id}
                className="group hover:shadow-lg transition-all duration-300 border-border relative"
              >
                {service.popular && (
                  <Badge className="absolute -top-2 -right-2 z-10">
                    <Star className="w-3 h-3 mr-1" />
                    Popular
                  </Badge>
                )}

                <div className="aspect-[4/3] overflow-hidden rounded-t-lg">
                  <img
                    src={service.image || "/placeholder.svg"}
                    alt={service.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>

                <CardHeader className="pb-2">
                  <CardTitle className="text-xl font-semibold">{service.name}</CardTitle>
                  <CardDescription className="text-sm">{service.description}</CardDescription>
                </CardHeader>

                <CardContent className="pt-0 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-primary">{service.price}</span>
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      <span>{service.duration}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">What's Included:</h4>
                    <ul className="text-xs text-muted-foreground space-y-1">
                      {service.features.map((feature, index) => (
                        <li key={index} className="flex items-center gap-2">
                          <div className="w-1 h-1 bg-primary rounded-full"></div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Button className="w-full" asChild>
                    <Link href="/booking">
                      <Calendar className="w-4 h-4 mr-2" />
                      Book Now
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-3xl md:text-4xl font-serif font-bold mb-4">Ready to Book?</h3>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Choose your service and book an appointment with our expert stylists today.
          </p>
          <Button size="lg" variant="secondary" className="text-lg px-8" asChild>
            <Link href="/booking">
              <Calendar className="mr-2 h-5 w-5" />
              Book Appointment
            </Link>
          </Button>
        </div>
      </section>
    </div>
  )
}
