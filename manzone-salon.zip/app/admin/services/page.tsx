"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, Edit, Trash2, Clock, DollarSign, ArrowLeft } from "lucide-react"
import Link from "next/link"

interface Service {
  id: number
  name: string
  description: string
  price: number
  duration: number
  category: string
  isActive: boolean
  image?: string
}

const initialServices: Service[] = [
  {
    id: 1,
    name: "Premium Haircut",
    description: "Professional styling with consultation and premium products",
    price: 800,
    duration: 45,
    category: "Hair",
    isActive: true,
    image: "/placeholder-mbvn4.png",
  },
  {
    id: 2,
    name: "Beard Styling",
    description: "Expert beard trimming and shaping with hot towel treatment",
    price: 500,
    duration: 30,
    category: "Beard",
    isActive: true,
    image: "/placeholder-w6mch.png",
  },
  {
    id: 3,
    name: "Facial Treatment",
    description: "Deep cleansing and rejuvenation facial with premium products",
    price: 1200,
    duration: 60,
    category: "Facial",
    isActive: true,
    image: "/placeholder-4lakq.png",
  },
  {
    id: 4,
    name: "Complete Grooming",
    description: "Haircut + Beard + Facial package for complete transformation",
    price: 2000,
    duration: 90,
    category: "Package",
    isActive: true,
    image: "/placeholder-huelz.png",
  },
  {
    id: 5,
    name: "Basic Haircut",
    description: "Simple haircut without styling",
    price: 400,
    duration: 30,
    category: "Hair",
    isActive: false,
  },
]

export default function ServiceManagement() {
  const [services, setServices] = useState<Service[]>(initialServices)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editingService, setEditingService] = useState<Service | null>(null)
  const [newService, setNewService] = useState<Partial<Service>>({
    name: "",
    description: "",
    price: 0,
    duration: 30,
    category: "Hair",
    isActive: true,
  })

  const categories = ["Hair", "Beard", "Facial", "Package", "Other"]

  const handleAddService = () => {
    if (newService.name && newService.description && newService.price && newService.duration) {
      const service: Service = {
        id: Math.max(...services.map((s) => s.id)) + 1,
        name: newService.name,
        description: newService.description,
        price: newService.price,
        duration: newService.duration,
        category: newService.category || "Hair",
        isActive: newService.isActive ?? true,
      }
      setServices([...services, service])
      setNewService({
        name: "",
        description: "",
        price: 0,
        duration: 30,
        category: "Hair",
        isActive: true,
      })
      setIsAddDialogOpen(false)
    }
  }

  const handleEditService = () => {
    if (editingService) {
      setServices(services.map((s) => (s.id === editingService.id ? editingService : s)))
      setEditingService(null)
      setIsEditDialogOpen(false)
    }
  }

  const handleDeleteService = (id: number) => {
    if (confirm("Are you sure you want to delete this service?")) {
      setServices(services.filter((s) => s.id !== id))
    }
  }

  const toggleServiceStatus = (id: number) => {
    setServices(services.map((s) => (s.id === id ? { ...s, isActive: !s.isActive } : s)))
  }

  const openEditDialog = (service: Service) => {
    setEditingService({ ...service })
    setIsEditDialogOpen(true)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/admin">
                <Button variant="outline" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-serif font-bold text-foreground">Service Management</h1>
                <p className="text-muted-foreground">Manage your salon services and pricing</p>
              </div>
            </div>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Service
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Add New Service</DialogTitle>
                  <DialogDescription>Create a new service for your salon</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Service Name</Label>
                    <Input
                      id="name"
                      value={newService.name}
                      onChange={(e) => setNewService({ ...newService, name: e.target.value })}
                      placeholder="Enter service name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={newService.description}
                      onChange={(e) => setNewService({ ...newService, description: e.target.value })}
                      placeholder="Enter service description"
                      rows={3}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="price">Price (₹)</Label>
                      <Input
                        id="price"
                        type="number"
                        value={newService.price}
                        onChange={(e) => setNewService({ ...newService, price: Number.parseInt(e.target.value) })}
                        placeholder="0"
                      />
                    </div>
                    <div>
                      <Label htmlFor="duration">Duration (min)</Label>
                      <Input
                        id="duration"
                        type="number"
                        value={newService.duration}
                        onChange={(e) => setNewService({ ...newService, duration: Number.parseInt(e.target.value) })}
                        placeholder="30"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="category">Category</Label>
                    <select
                      id="category"
                      className="w-full p-2 border rounded-md"
                      value={newService.category}
                      onChange={(e) => setNewService({ ...newService, category: e.target.value })}
                    >
                      {categories.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="isActive"
                      checked={newService.isActive}
                      onChange={(e) => setNewService({ ...newService, isActive: e.target.checked })}
                    />
                    <Label htmlFor="isActive">Active Service</Label>
                  </div>
                  <div className="flex gap-2 pt-4">
                    <Button onClick={handleAddService} className="flex-1">
                      Add Service
                    </Button>
                    <Button variant="outline" onClick={() => setIsAddDialogOpen(false)} className="flex-1">
                      Cancel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <Card key={service.id} className={`${!service.isActive ? "opacity-60" : ""}`}>
              {service.image && (
                <div className="aspect-[4/3] overflow-hidden rounded-t-lg">
                  <img
                    src={service.image || "/placeholder.svg"}
                    alt={service.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg">{service.name}</CardTitle>
                    <CardDescription className="text-sm mt-1">{service.description}</CardDescription>
                  </div>
                  <Badge variant={service.isActive ? "default" : "secondary"}>
                    {service.isActive ? "Active" : "Inactive"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <DollarSign className="w-4 h-4 text-primary" />
                      <span className="font-bold text-primary">₹{service.price}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">{service.duration} min</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Badge variant="outline">{service.category}</Badge>
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <Button size="sm" variant="outline" onClick={() => openEditDialog(service)} className="flex-1">
                    <Edit className="w-4 h-4 mr-1" />
                    Edit
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => toggleServiceStatus(service.id)}
                    className="flex-1"
                  >
                    {service.isActive ? "Deactivate" : "Activate"}
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleDeleteService(service.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Edit Service Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Edit Service</DialogTitle>
              <DialogDescription>Update service information</DialogDescription>
            </DialogHeader>
            {editingService && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit-name">Service Name</Label>
                  <Input
                    id="edit-name"
                    value={editingService.name}
                    onChange={(e) => setEditingService({ ...editingService, name: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-description">Description</Label>
                  <Textarea
                    id="edit-description"
                    value={editingService.description}
                    onChange={(e) => setEditingService({ ...editingService, description: e.target.value })}
                    rows={3}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="edit-price">Price (₹)</Label>
                    <Input
                      id="edit-price"
                      type="number"
                      value={editingService.price}
                      onChange={(e) => setEditingService({ ...editingService, price: Number.parseInt(e.target.value) })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-duration">Duration (min)</Label>
                    <Input
                      id="edit-duration"
                      type="number"
                      value={editingService.duration}
                      onChange={(e) =>
                        setEditingService({ ...editingService, duration: Number.parseInt(e.target.value) })
                      }
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="edit-category">Category</Label>
                  <select
                    id="edit-category"
                    className="w-full p-2 border rounded-md"
                    value={editingService.category}
                    onChange={(e) => setEditingService({ ...editingService, category: e.target.value })}
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="edit-isActive"
                    checked={editingService.isActive}
                    onChange={(e) => setEditingService({ ...editingService, isActive: e.target.checked })}
                  />
                  <Label htmlFor="edit-isActive">Active Service</Label>
                </div>
                <div className="flex gap-2 pt-4">
                  <Button onClick={handleEditService} className="flex-1">
                    Update Service
                  </Button>
                  <Button variant="outline" onClick={() => setIsEditDialogOpen(false)} className="flex-1">
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
