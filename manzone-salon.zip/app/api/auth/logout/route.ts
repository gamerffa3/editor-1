import { NextResponse } from "next/server"
import { cookies } from "next/headers"

export async function POST() {
  cookies().delete("auth_token")
  cookies().delete("user_session") // Keep for backward compatibility
  cookies().delete("admin_session") // Keep for backward compatibility

  return NextResponse.json({ success: true })
}
