"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, Edit, Trash2, Star, Calendar, Phone, Mail, ArrowLeft, Clock } from "lucide-react"
import Link from "next/link"

interface StaffMember {
  id: number
  name: string
  specialty: string
  email: string
  phone: string
  experience: string
  rating: number
  totalBookings: number
  isActive: boolean
  workingDays: string[]
  workingHours: {
    start: string
    end: string
  }
  image?: string
  bio?: string
}

const initialStaff: StaffMember[] = [
  {
    id: 1,
    name: "Rajesh Kumar",
    specialty: "Senior Hair Stylist",
    email: "rajesh@manzone.com",
    phone: "+91 98765 43210",
    experience: "8+ years",
    rating: 4.9,
    totalBookings: 156,
    isActive: true,
    workingDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
    workingHours: { start: "09:00", end: "18:00" },
    image: "/professional-male-barber.png",
    bio: "Expert in modern and classic haircuts with 8 years of experience in premium salons.",
  },
  {
    id: 2,
    name: "Amit Singh",
    specialty: "Beard Specialist",
    email: "amit@manzone.com",
    phone: "+91 98765 43211",
    experience: "6+ years",
    rating: 4.8,
    totalBookings: 124,
    isActive: true,
    workingDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    workingHours: { start: "10:00", end: "19:00" },
    image: "/professional-male-barber.png",
    bio: "Specialized in beard styling and grooming with expertise in traditional techniques.",
  },
  {
    id: 3,
    name: "Vikram Sharma",
    specialty: "Facial Expert",
    email: "vikram@manzone.com",
    phone: "+91 98765 43212",
    experience: "5+ years",
    rating: 4.9,
    totalBookings: 98,
    isActive: true,
    workingDays: ["Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    workingHours: { start: "11:00", end: "20:00" },
    image: "/professional-male-barber.png",
    bio: "Expert in facial treatments and skincare with certification in advanced techniques.",
  },
]

const daysOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
const specialties = ["Hair Stylist", "Beard Specialist", "Facial Expert", "Senior Stylist", "Trainee", "Manager"]

export default function StaffManagement() {
  const [staff, setStaff] = useState<StaffMember[]>(initialStaff)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null)
  const [newStaff, setNewStaff] = useState<Partial<StaffMember>>({
    name: "",
    specialty: "Hair Stylist",
    email: "",
    phone: "",
    experience: "",
    rating: 5.0,
    totalBookings: 0,
    isActive: true,
    workingDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    workingHours: { start: "09:00", end: "18:00" },
    bio: "",
  })

  const handleAddStaff = () => {
    if (newStaff.name && newStaff.email && newStaff.phone && newStaff.specialty) {
      const staffMember: StaffMember = {
        id: Math.max(...staff.map((s) => s.id)) + 1,
        name: newStaff.name,
        specialty: newStaff.specialty,
        email: newStaff.email,
        phone: newStaff.phone,
        experience: newStaff.experience || "0 years",
        rating: newStaff.rating || 5.0,
        totalBookings: 0,
        isActive: newStaff.isActive ?? true,
        workingDays: newStaff.workingDays || ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        workingHours: newStaff.workingHours || { start: "09:00", end: "18:00" },
        bio: newStaff.bio || "",
      }
      setStaff([...staff, staffMember])
      setNewStaff({
        name: "",
        specialty: "Hair Stylist",
        email: "",
        phone: "",
        experience: "",
        rating: 5.0,
        totalBookings: 0,
        isActive: true,
        workingDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        workingHours: { start: "09:00", end: "18:00" },
        bio: "",
      })
      setIsAddDialogOpen(false)
    }
  }

  const handleEditStaff = () => {
    if (editingStaff) {
      setStaff(staff.map((s) => (s.id === editingStaff.id ? editingStaff : s)))
      setEditingStaff(null)
      setIsEditDialogOpen(false)
    }
  }

  const handleDeleteStaff = (id: number) => {
    if (confirm("Are you sure you want to delete this staff member?")) {
      setStaff(staff.filter((s) => s.id !== id))
    }
  }

  const toggleStaffStatus = (id: number) => {
    setStaff(staff.map((s) => (s.id === id ? { ...s, isActive: !s.isActive } : s)))
  }

  const openEditDialog = (staffMember: StaffMember) => {
    setEditingStaff({ ...staffMember })
    setIsEditDialogOpen(true)
  }

  const handleWorkingDaysChange = (day: string, checked: boolean, isEditing = false) => {
    if (isEditing && editingStaff) {
      const updatedDays = checked
        ? [...editingStaff.workingDays, day]
        : editingStaff.workingDays.filter((d) => d !== day)
      setEditingStaff({ ...editingStaff, workingDays: updatedDays })
    } else {
      const updatedDays = checked
        ? [...(newStaff.workingDays || []), day]
        : (newStaff.workingDays || []).filter((d) => d !== day)
      setNewStaff({ ...newStaff, workingDays: updatedDays })
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/admin">
                <Button variant="outline" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-serif font-bold text-foreground">Staff Management</h1>
                <p className="text-muted-foreground">Manage your salon team and schedules</p>
              </div>
            </div>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Staff Member
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Add New Staff Member</DialogTitle>
                  <DialogDescription>Add a new team member to your salon</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        value={newStaff.name}
                        onChange={(e) => setNewStaff({ ...newStaff, name: e.target.value })}
                        placeholder="Enter full name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="specialty">Specialty</Label>
                      <select
                        id="specialty"
                        className="w-full p-2 border rounded-md"
                        value={newStaff.specialty}
                        onChange={(e) => setNewStaff({ ...newStaff, specialty: e.target.value })}
                      >
                        {specialties.map((spec) => (
                          <option key={spec} value={spec}>
                            {spec}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={newStaff.email}
                        onChange={(e) => setNewStaff({ ...newStaff, email: e.target.value })}
                        placeholder="email@example.com"
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone</Label>
                      <Input
                        id="phone"
                        value={newStaff.phone}
                        onChange={(e) => setNewStaff({ ...newStaff, phone: e.target.value })}
                        placeholder="+91 98765 43210"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="experience">Experience</Label>
                    <Input
                      id="experience"
                      value={newStaff.experience}
                      onChange={(e) => setNewStaff({ ...newStaff, experience: e.target.value })}
                      placeholder="e.g., 5+ years"
                    />
                  </div>
                  <div>
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea
                      id="bio"
                      value={newStaff.bio}
                      onChange={(e) => setNewStaff({ ...newStaff, bio: e.target.value })}
                      placeholder="Brief description about the staff member"
                      rows={3}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="start-time">Start Time</Label>
                      <Input
                        id="start-time"
                        type="time"
                        value={newStaff.workingHours?.start}
                        onChange={(e) =>
                          setNewStaff({
                            ...newStaff,
                            workingHours: { ...newStaff.workingHours!, start: e.target.value },
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="end-time">End Time</Label>
                      <Input
                        id="end-time"
                        type="time"
                        value={newStaff.workingHours?.end}
                        onChange={(e) =>
                          setNewStaff({
                            ...newStaff,
                            workingHours: { ...newStaff.workingHours!, end: e.target.value },
                          })
                        }
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Working Days</Label>
                    <div className="grid grid-cols-4 gap-2 mt-2">
                      {daysOfWeek.map((day) => (
                        <div key={day} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id={`day-${day}`}
                            checked={newStaff.workingDays?.includes(day)}
                            onChange={(e) => handleWorkingDaysChange(day, e.target.checked)}
                          />
                          <Label htmlFor={`day-${day}`} className="text-sm">
                            {day.slice(0, 3)}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="isActive"
                      checked={newStaff.isActive}
                      onChange={(e) => setNewStaff({ ...newStaff, isActive: e.target.checked })}
                    />
                    <Label htmlFor="isActive">Active Staff Member</Label>
                  </div>
                  <div className="flex gap-2 pt-4">
                    <Button onClick={handleAddStaff} className="flex-1">
                      Add Staff Member
                    </Button>
                    <Button variant="outline" onClick={() => setIsAddDialogOpen(false)} className="flex-1">
                      Cancel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Staff Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {staff.map((member) => (
            <Card key={member.id} className={`${!member.isActive ? "opacity-60" : ""}`}>
              <CardHeader className="text-center">
                <div className="w-20 h-20 mx-auto mb-4 rounded-full overflow-hidden">
                  <img
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-left flex-1">
                    <CardTitle className="text-lg">{member.name}</CardTitle>
                    <CardDescription className="text-primary font-medium">{member.specialty}</CardDescription>
                  </div>
                  <Badge variant={member.isActive ? "default" : "secondary"}>
                    {member.isActive ? "Active" : "Inactive"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{member.email}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{member.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">
                      {member.workingHours.start} - {member.workingHours.end}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span>{member.rating}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span>{member.totalBookings}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-2">Experience: {member.experience}</p>
                  {member.bio && <p className="text-xs text-muted-foreground">{member.bio}</p>}
                </div>

                <div>
                  <p className="text-sm font-medium mb-2">Working Days:</p>
                  <div className="flex flex-wrap gap-1">
                    {member.workingDays.map((day) => (
                      <Badge key={day} variant="outline" className="text-xs">
                        {day.slice(0, 3)}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <Button size="sm" variant="outline" onClick={() => openEditDialog(member)} className="flex-1">
                    <Edit className="w-4 h-4 mr-1" />
                    Edit
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => toggleStaffStatus(member.id)} className="flex-1">
                    {member.isActive ? "Deactivate" : "Activate"}
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleDeleteStaff(member.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Edit Staff Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Staff Member</DialogTitle>
              <DialogDescription>Update staff member information</DialogDescription>
            </DialogHeader>
            {editingStaff && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="edit-name">Full Name</Label>
                    <Input
                      id="edit-name"
                      value={editingStaff.name}
                      onChange={(e) => setEditingStaff({ ...editingStaff, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-specialty">Specialty</Label>
                    <select
                      id="edit-specialty"
                      className="w-full p-2 border rounded-md"
                      value={editingStaff.specialty}
                      onChange={(e) => setEditingStaff({ ...editingStaff, specialty: e.target.value })}
                    >
                      {specialties.map((spec) => (
                        <option key={spec} value={spec}>
                          {spec}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="edit-email">Email</Label>
                    <Input
                      id="edit-email"
                      type="email"
                      value={editingStaff.email}
                      onChange={(e) => setEditingStaff({ ...editingStaff, email: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-phone">Phone</Label>
                    <Input
                      id="edit-phone"
                      value={editingStaff.phone}
                      onChange={(e) => setEditingStaff({ ...editingStaff, phone: e.target.value })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="edit-experience">Experience</Label>
                  <Input
                    id="edit-experience"
                    value={editingStaff.experience}
                    onChange={(e) => setEditingStaff({ ...editingStaff, experience: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-bio">Bio</Label>
                  <Textarea
                    id="edit-bio"
                    value={editingStaff.bio}
                    onChange={(e) => setEditingStaff({ ...editingStaff, bio: e.target.value })}
                    rows={3}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="edit-start-time">Start Time</Label>
                    <Input
                      id="edit-start-time"
                      type="time"
                      value={editingStaff.workingHours.start}
                      onChange={(e) =>
                        setEditingStaff({
                          ...editingStaff,
                          workingHours: { ...editingStaff.workingHours, start: e.target.value },
                        })
                      }
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-end-time">End Time</Label>
                    <Input
                      id="edit-end-time"
                      type="time"
                      value={editingStaff.workingHours.end}
                      onChange={(e) =>
                        setEditingStaff({
                          ...editingStaff,
                          workingHours: { ...editingStaff.workingHours, end: e.target.value },
                        })
                      }
                    />
                  </div>
                </div>
                <div>
                  <Label>Working Days</Label>
                  <div className="grid grid-cols-4 gap-2 mt-2">
                    {daysOfWeek.map((day) => (
                      <div key={day} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={`edit-day-${day}`}
                          checked={editingStaff.workingDays.includes(day)}
                          onChange={(e) => handleWorkingDaysChange(day, e.target.checked, true)}
                        />
                        <Label htmlFor={`edit-day-${day}`} className="text-sm">
                          {day.slice(0, 3)}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="edit-isActive"
                    checked={editingStaff.isActive}
                    onChange={(e) => setEditingStaff({ ...editingStaff, isActive: e.target.checked })}
                  />
                  <Label htmlFor="edit-isActive">Active Staff Member</Label>
                </div>
                <div className="flex gap-2 pt-4">
                  <Button onClick={handleEditStaff} className="flex-1">
                    Update Staff Member
                  </Button>
                  <Button variant="outline" onClick={() => setIsEditDialogOpen(false)} className="flex-1">
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
