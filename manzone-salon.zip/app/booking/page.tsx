"use client"

import { useState } from "react"
import { Header } from "@/components/navigation/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, User, CheckCircle, ArrowLeft, ArrowRight } from "lucide-react"

const services = [
  {
    id: 1,
    name: "Premium Haircut",
    description: "Professional styling with consultation",
    price: 800,
    duration: 45,
    image: "/placeholder-mbvn4.png",
  },
  {
    id: 2,
    name: "Beard Styling",
    description: "Expert beard trimming and shaping",
    price: 500,
    duration: 30,
    image: "/placeholder-w6mch.png",
  },
  {
    id: 3,
    name: "Facial Treatment",
    description: "Deep cleansing and rejuvenation",
    price: 1200,
    duration: 60,
    image: "/placeholder-4lakq.png",
  },
  {
    id: 4,
    name: "Complete Grooming",
    description: "Haircut + Beard + Facial package",
    price: 2000,
    duration: 90,
    image: "/placeholder-huelz.png",
  },
]

const staff = [
  {
    id: 1,
    name: "Rajesh Kumar",
    specialty: "Senior Hair Stylist",
    rating: 4.9,
    experience: "8+ years",
    image: "/professional-male-barber.png",
  },
  {
    id: 2,
    name: "Amit Singh",
    specialty: "Beard Specialist",
    rating: 4.8,
    experience: "6+ years",
    image: "/professional-male-barber.png",
  },
  {
    id: 3,
    name: "Vikram Sharma",
    specialty: "Facial Expert",
    rating: 4.9,
    experience: "5+ years",
    image: "/professional-male-barber.png",
  },
]

const timeSlots = [
  "09:00",
  "09:30",
  "10:00",
  "10:30",
  "11:00",
  "11:30",
  "12:00",
  "12:30",
  "14:00",
  "14:30",
  "15:00",
  "15:30",
  "16:00",
  "16:30",
  "17:00",
  "17:30",
  "18:00",
  "18:30",
]

export default function BookingPage() {
  const [currentStep, setCurrentStep] = useState(1)
  const [selectedService, setSelectedService] = useState<(typeof services)[0] | null>(null)
  const [selectedStaff, setSelectedStaff] = useState<(typeof staff)[0] | null>(null)
  const [selectedDate, setSelectedDate] = useState<string>("")
  const [selectedTime, setSelectedTime] = useState<string>("")
  const [customerDetails, setCustomerDetails] = useState({
    name: "",
    email: "",
    phone: "",
    notes: "",
  })

  const steps = [
    { number: 1, title: "Select Service", icon: Calendar },
    { number: 2, title: "Choose Staff", icon: User },
    { number: 3, title: "Pick Date & Time", icon: Clock },
    { number: 4, title: "Your Details", icon: User },
    { number: 5, title: "Confirm", icon: CheckCircle },
  ]

  const nextStep = () => {
    if (currentStep < 5) setCurrentStep(currentStep + 1)
  }

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1)
  }

  const generateDateOptions = () => {
    const dates = []
    const today = new Date()
    for (let i = 0; i < 14; i++) {
      const date = new Date(today)
      date.setDate(today.getDate() + i)
      dates.push(date.toISOString().split("T")[0])
    }
    return dates
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
    })
  }

  const handleBooking = () => {
    // TODO: Implement booking logic
    console.log("Booking details:", {
      service: selectedService,
      staff: selectedStaff,
      date: selectedDate,
      time: selectedTime,
      customer: customerDetails,
    })
    alert("Booking confirmed! You will receive a confirmation email shortly.")
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Progress Steps */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              {steps.map((step, index) => (
                <div key={step.number} className="flex items-center">
                  <div
                    className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                      currentStep >= step.number
                        ? "bg-primary border-primary text-primary-foreground"
                        : "border-muted-foreground text-muted-foreground"
                    }`}
                  >
                    {currentStep > step.number ? (
                      <CheckCircle className="w-5 h-5" />
                    ) : (
                      <step.icon className="w-5 h-5" />
                    )}
                  </div>
                  <div className="ml-2 hidden sm:block">
                    <div
                      className={`text-sm font-medium ${
                        currentStep >= step.number ? "text-foreground" : "text-muted-foreground"
                      }`}
                    >
                      {step.title}
                    </div>
                  </div>
                  {index < steps.length - 1 && (
                    <div
                      className={`w-8 sm:w-16 h-0.5 mx-2 sm:mx-4 ${
                        currentStep > step.number ? "bg-primary" : "bg-muted"
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Step Content */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="text-2xl font-serif">{steps[currentStep - 1].title}</CardTitle>
              <CardDescription>
                {currentStep === 1 && "Choose the service you'd like to book"}
                {currentStep === 2 && "Select your preferred staff member"}
                {currentStep === 3 && "Pick your preferred date and time"}
                {currentStep === 4 && "Enter your contact information"}
                {currentStep === 5 && "Review and confirm your booking"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Step 1: Select Service */}
              {currentStep === 1 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {services.map((service) => (
                    <Card
                      key={service.id}
                      className={`cursor-pointer transition-all ${
                        selectedService?.id === service.id ? "ring-2 ring-primary bg-primary/5" : "hover:shadow-md"
                      }`}
                      onClick={() => setSelectedService(service)}
                    >
                      <div className="aspect-[4/3] overflow-hidden rounded-t-lg">
                        <img
                          src={service.image || "/placeholder.svg"}
                          alt={service.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg">{service.name}</CardTitle>
                        <CardDescription>{service.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xl font-bold text-primary">₹{service.price}</span>
                          <Badge variant="secondary">{service.duration} min</Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {/* Step 2: Choose Staff */}
              {currentStep === 2 && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {staff.map((member) => (
                    <Card
                      key={member.id}
                      className={`cursor-pointer transition-all text-center ${
                        selectedStaff?.id === member.id ? "ring-2 ring-primary bg-primary/5" : "hover:shadow-md"
                      }`}
                      onClick={() => setSelectedStaff(member)}
                    >
                      <CardHeader>
                        <div className="w-20 h-20 mx-auto mb-4 rounded-full overflow-hidden">
                          <img
                            src={member.image || "/placeholder.svg"}
                            alt={member.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <CardTitle className="text-lg">{member.name}</CardTitle>
                        <CardDescription>{member.specialty}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
                          <span>⭐ {member.rating}</span>
                          <span>{member.experience}</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {/* Step 3: Date & Time */}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <div>
                    <h4 className="font-semibold mb-4">Select Date</h4>
                    <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2">
                      {generateDateOptions().map((date) => (
                        <Button
                          key={date}
                          variant={selectedDate === date ? "default" : "outline"}
                          className="h-auto p-3 flex flex-col"
                          onClick={() => setSelectedDate(date)}
                        >
                          <span className="text-xs">{formatDate(date)}</span>
                        </Button>
                      ))}
                    </div>
                  </div>

                  {selectedDate && (
                    <div>
                      <h4 className="font-semibold mb-4">Select Time</h4>
                      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
                        {timeSlots.map((time) => (
                          <Button
                            key={time}
                            variant={selectedTime === time ? "default" : "outline"}
                            onClick={() => setSelectedTime(time)}
                          >
                            {time}
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Step 4: Customer Details */}
              {currentStep === 4 && (
                <div className="space-y-4 max-w-md">
                  <div>
                    <label className="block text-sm font-medium mb-2">Full Name</label>
                    <input
                      type="text"
                      className="w-full p-3 border rounded-lg"
                      value={customerDetails.name}
                      onChange={(e) => setCustomerDetails((prev) => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter your full name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Email</label>
                    <input
                      type="email"
                      className="w-full p-3 border rounded-lg"
                      value={customerDetails.email}
                      onChange={(e) => setCustomerDetails((prev) => ({ ...prev, email: e.target.value }))}
                      placeholder="your@email.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Phone Number</label>
                    <input
                      type="tel"
                      className="w-full p-3 border rounded-lg"
                      value={customerDetails.phone}
                      onChange={(e) => setCustomerDetails((prev) => ({ ...prev, phone: e.target.value }))}
                      placeholder="+91 98765 43210"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Special Notes (Optional)</label>
                    <textarea
                      className="w-full p-3 border rounded-lg"
                      rows={3}
                      value={customerDetails.notes}
                      onChange={(e) => setCustomerDetails((prev) => ({ ...prev, notes: e.target.value }))}
                      placeholder="Any special requests or notes..."
                    />
                  </div>
                </div>
              )}

              {/* Step 5: Confirmation */}
              {currentStep === 5 && (
                <div className="space-y-6">
                  <div className="bg-muted/50 p-6 rounded-lg">
                    <h4 className="font-semibold mb-4">Booking Summary</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>Service:</span>
                        <span className="font-medium">{selectedService?.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Staff:</span>
                        <span className="font-medium">{selectedStaff?.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Date:</span>
                        <span className="font-medium">{selectedDate && formatDate(selectedDate)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Time:</span>
                        <span className="font-medium">{selectedTime}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Duration:</span>
                        <span className="font-medium">{selectedService?.duration} minutes</span>
                      </div>
                      <div className="border-t pt-3 flex justify-between text-lg font-bold">
                        <span>Total:</span>
                        <span className="text-primary">₹{selectedService?.price}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-muted/50 p-6 rounded-lg">
                    <h4 className="font-semibold mb-4">Customer Details</h4>
                    <div className="space-y-2">
                      <p>
                        <strong>Name:</strong> {customerDetails.name}
                      </p>
                      <p>
                        <strong>Email:</strong> {customerDetails.email}
                      </p>
                      <p>
                        <strong>Phone:</strong> {customerDetails.phone}
                      </p>
                      {customerDetails.notes && (
                        <p>
                          <strong>Notes:</strong> {customerDetails.notes}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Navigation Buttons */}
          <div className="flex justify-between">
            <Button variant="outline" onClick={prevStep} disabled={currentStep === 1}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Previous
            </Button>

            {currentStep < 5 ? (
              <Button
                onClick={nextStep}
                disabled={
                  (currentStep === 1 && !selectedService) ||
                  (currentStep === 2 && !selectedStaff) ||
                  (currentStep === 3 && (!selectedDate || !selectedTime)) ||
                  (currentStep === 4 && (!customerDetails.name || !customerDetails.email || !customerDetails.phone))
                }
              >
                Next
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <Button onClick={handleBooking} className="bg-primary">
                Confirm Booking
                <CheckCircle className="w-4 h-4 ml-2" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
