"use client"

import { useState } from "react"
import { useSearchParams } from "next/navigation"
import { Header } from "@/components/navigation/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CreditCard, Smartphone, Wallet, Shield, CheckCircle, ArrowLeft, Calendar, Clock, User } from "lucide-react"
import Link from "next/link"

export default function PaymentPage() {
  const searchParams = useSearchParams()
  const [paymentMethod, setPaymentMethod] = useState("upi")
  const [isProcessing, setIsProcessing] = useState(false)
  const [paymentComplete, setPaymentComplete] = useState(false)
  const [cardDetails, setCardDetails] = useState({
    number: "",
    expiry: "",
    cvv: "",
    name: "",
  })
  const [upiId, setUpiId] = useState("")

  // Mock booking data (in real app, this would come from booking context/state)
  const bookingData = {
    service: "Premium Haircut",
    staff: "Rajesh Kumar",
    date: "2024-01-15",
    time: "10:00",
    duration: 45,
    amount: 800,
    customer: {
      name: "John Doe",
      email: "john@example.com",
      phone: "+91 98765 43210",
    },
  }

  const handlePayment = async () => {
    setIsProcessing(true)

    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false)
      setPaymentComplete(true)
    }, 3000)
  }

  if (paymentComplete) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-2xl mx-auto">
            <Card className="text-center">
              <CardHeader>
                <div className="w-16 h-16 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
                <CardTitle className="text-2xl font-serif text-green-600">Payment Successful!</CardTitle>
                <CardDescription>Your booking has been confirmed</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-muted/50 p-6 rounded-lg text-left">
                  <h4 className="font-semibold mb-4">Booking Confirmation</h4>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span>Booking ID:</span>
                      <span className="font-medium">#MZ{Math.random().toString().slice(2, 8)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Service:</span>
                      <span className="font-medium">{bookingData.service}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Staff:</span>
                      <span className="font-medium">{bookingData.staff}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Date & Time:</span>
                      <span className="font-medium">
                        {bookingData.date} at {bookingData.time}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Duration:</span>
                      <span className="font-medium">{bookingData.duration} minutes</span>
                    </div>
                    <div className="border-t pt-3 flex justify-between font-bold">
                      <span>Amount Paid:</span>
                      <span className="text-primary">₹{bookingData.amount}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>What's Next?</strong>
                    <br />• You'll receive a confirmation email shortly
                    <br />• Arrive 10 minutes before your appointment
                    <br />• Bring a valid ID for verification
                  </p>
                </div>

                <div className="flex gap-4">
                  <Button asChild className="flex-1">
                    <Link href="/">Return Home</Link>
                  </Button>
                  <Button variant="outline" className="flex-1 bg-transparent">
                    Download Receipt
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4 mb-8">
            <Link href="/booking">
              <Button variant="outline" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Booking
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-serif font-bold">Complete Payment</h1>
              <p className="text-muted-foreground">Secure payment for your appointment</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Booking Summary */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Booking Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="font-medium">{bookingData.service}</p>
                        <p className="text-sm text-muted-foreground">with {bookingData.staff}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="font-medium">{bookingData.date}</p>
                        <p className="text-sm text-muted-foreground">
                          {bookingData.time} ({bookingData.duration} min)
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <User className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="font-medium">{bookingData.customer.name}</p>
                        <p className="text-sm text-muted-foreground">{bookingData.customer.phone}</p>
                      </div>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-bold">Total Amount</span>
                      <span className="text-2xl font-bold text-primary">₹{bookingData.amount}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Shield className="w-4 h-4" />
                    <span>Secure payment powered by industry standards</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Payment Methods */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Choose Payment Method</CardTitle>
                  <CardDescription>Select your preferred payment option</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs value={paymentMethod} onValueChange={setPaymentMethod}>
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="upi" className="flex items-center gap-2">
                        <Smartphone className="w-4 h-4" />
                        UPI
                      </TabsTrigger>
                      <TabsTrigger value="card" className="flex items-center gap-2">
                        <CreditCard className="w-4 h-4" />
                        Card
                      </TabsTrigger>
                      <TabsTrigger value="wallet" className="flex items-center gap-2">
                        <Wallet className="w-4 h-4" />
                        Wallet
                      </TabsTrigger>
                    </TabsList>

                    {/* UPI Payment */}
                    <TabsContent value="upi" className="space-y-4">
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="upi-id">UPI ID</Label>
                          <Input
                            id="upi-id"
                            placeholder="yourname@upi"
                            value={upiId}
                            onChange={(e) => setUpiId(e.target.value)}
                          />
                        </div>
                        <div className="grid grid-cols-3 gap-4">
                          <Button variant="outline" className="h-16 flex flex-col items-center gap-2 bg-transparent">
                            <div className="w-8 h-8 bg-blue-600 rounded"></div>
                            <span className="text-xs">PhonePe</span>
                          </Button>
                          <Button variant="outline" className="h-16 flex flex-col items-center gap-2 bg-transparent">
                            <div className="w-8 h-8 bg-purple-600 rounded"></div>
                            <span className="text-xs">Google Pay</span>
                          </Button>
                          <Button variant="outline" className="h-16 flex flex-col items-center gap-2 bg-transparent">
                            <div className="w-8 h-8 bg-indigo-600 rounded"></div>
                            <span className="text-xs">Paytm</span>
                          </Button>
                        </div>
                      </div>
                    </TabsContent>

                    {/* Card Payment */}
                    <TabsContent value="card" className="space-y-4">
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="card-number">Card Number</Label>
                          <Input
                            id="card-number"
                            placeholder="1234 5678 9012 3456"
                            value={cardDetails.number}
                            onChange={(e) => setCardDetails({ ...cardDetails, number: e.target.value })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="card-name">Cardholder Name</Label>
                          <Input
                            id="card-name"
                            placeholder="John Doe"
                            value={cardDetails.name}
                            onChange={(e) => setCardDetails({ ...cardDetails, name: e.target.value })}
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="expiry">Expiry Date</Label>
                            <Input
                              id="expiry"
                              placeholder="MM/YY"
                              value={cardDetails.expiry}
                              onChange={(e) => setCardDetails({ ...cardDetails, expiry: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label htmlFor="cvv">CVV</Label>
                            <Input
                              id="cvv"
                              placeholder="123"
                              value={cardDetails.cvv}
                              onChange={(e) => setCardDetails({ ...cardDetails, cvv: e.target.value })}
                            />
                          </div>
                        </div>
                        <div className="flex gap-4">
                          <Badge variant="outline">Visa</Badge>
                          <Badge variant="outline">Mastercard</Badge>
                          <Badge variant="outline">RuPay</Badge>
                        </div>
                      </div>
                    </TabsContent>

                    {/* Wallet Payment */}
                    <TabsContent value="wallet" className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <Button variant="outline" className="h-20 flex flex-col items-center gap-2 bg-transparent">
                          <div className="w-10 h-10 bg-blue-500 rounded-full"></div>
                          <span>Paytm Wallet</span>
                          <span className="text-xs text-muted-foreground">Balance: ₹2,500</span>
                        </Button>
                        <Button variant="outline" className="h-20 flex flex-col items-center gap-2 bg-transparent">
                          <div className="w-10 h-10 bg-orange-500 rounded-full"></div>
                          <span>Amazon Pay</span>
                          <span className="text-xs text-muted-foreground">Balance: ₹1,200</span>
                        </Button>
                        <Button variant="outline" className="h-20 flex flex-col items-center gap-2 bg-transparent">
                          <div className="w-10 h-10 bg-green-500 rounded-full"></div>
                          <span>Mobikwik</span>
                          <span className="text-xs text-muted-foreground">Balance: ₹800</span>
                        </Button>
                        <Button variant="outline" className="h-20 flex flex-col items-center gap-2 bg-transparent">
                          <div className="w-10 h-10 bg-purple-500 rounded-full"></div>
                          <span>Freecharge</span>
                          <span className="text-xs text-muted-foreground">Balance: ₹1,500</span>
                        </Button>
                      </div>
                    </TabsContent>
                  </Tabs>

                  <div className="mt-8 pt-6 border-t">
                    <Button onClick={handlePayment} disabled={isProcessing} className="w-full h-12 text-lg">
                      {isProcessing ? (
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          Processing Payment...
                        </div>
                      ) : (
                        `Pay ₹${bookingData.amount}`
                      )}
                    </Button>

                    <div className="mt-4 text-center text-xs text-muted-foreground">
                      <p>By proceeding, you agree to our Terms & Conditions</p>
                      <div className="flex items-center justify-center gap-4 mt-2">
                        <div className="flex items-center gap-1">
                          <Shield className="w-3 h-3" />
                          <span>SSL Secured</span>
                        </div>
                        <span>•</span>
                        <span>256-bit Encryption</span>
                        <span>•</span>
                        <span>PCI DSS Compliant</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
