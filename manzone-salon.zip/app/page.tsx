import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, Star, Users, Sparkles } from "lucide-react"
import { Header } from "@/components/navigation/header"
import Link from "next/link"
import { Footer } from "@/components/footer"

export default function HomePage() {
  const services = [
    {
      id: 1,
      name: "Premium Haircut",
      description: "Professional styling with consultation",
      price: "₹800",
      duration: "45 min",
      image: "/placeholder-mbvn4.png",
    },
    {
      id: 2,
      name: "Beard Styling",
      description: "Expert beard trimming and shaping",
      price: "₹500",
      duration: "30 min",
      image: "/placeholder-w6mch.png",
    },
    {
      id: 3,
      name: "Facial Treatment",
      description: "Deep cleansing and rejuvenation",
      price: "₹1200",
      duration: "60 min",
      image: "/placeholder-4lakq.png",
    },
    {
      id: 4,
      name: "Complete Grooming",
      description: "Haircut + Beard + Facial package",
      price: "₹2000",
      duration: "90 min",
      image: "/placeholder-huelz.png",
    },
  ]

  const staff = [
    {
      id: 1,
      name: "Rajesh Kumar",
      specialty: "Senior Hair Stylist",
      rating: 4.9,
      experience: "8+ years",
      image: "/professional-male-barber.png",
    },
    {
      id: 2,
      name: "Amit Singh",
      specialty: "Beard Specialist",
      rating: 4.8,
      experience: "6+ years",
      image: "/professional-male-barber.png",
    },
    {
      id: 3,
      name: "Vikram Sharma",
      specialty: "Facial Expert",
      rating: 4.9,
      experience: "5+ years",
      image: "/professional-male-barber.png",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-card to-background py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="secondary" className="mb-4">
              Premium Men's Grooming
            </Badge>
            <h2 className="text-4xl md:text-6xl font-serif font-bold text-foreground mb-6 text-balance">
              Where Style Meets <span className="text-primary">Excellence</span>
            </h2>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 text-pretty max-w-2xl mx-auto">
              Experience premium grooming services at MANZONE. Professional haircuts, expert beard styling, and
              rejuvenating treatments for the modern gentleman.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <Link href="/booking">
                  <Calendar className="mr-2 h-5 w-5" />
                  Book Appointment
                </Link>
              </Button>
              <Button variant="outline" size="lg" className="text-lg px-8 bg-transparent" asChild>
                <Link href="/about">View Services</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">Our Services</h3>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Professional grooming services tailored for the modern man
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service) => (
              <Card key={service.id} className="group hover:shadow-lg transition-all duration-300 border-border">
                <div className="aspect-[4/3] overflow-hidden rounded-t-lg">
                  <img
                    src={service.image || "/placeholder.svg"}
                    alt={service.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-semibold">{service.name}</CardTitle>
                  <CardDescription className="text-sm">{service.description}</CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-bold text-primary">{service.price}</span>
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      <span>{service.duration}</span>
                    </div>
                  </div>
                  <Button className="w-full" size="sm" asChild>
                    <Link href="/booking">Book Now</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Staff Section */}
      <section className="py-16 bg-card/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">Meet Our Experts</h3>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Skilled professionals dedicated to your grooming excellence
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {staff.map((member) => (
              <Card key={member.id} className="text-center border-border">
                <CardHeader className="pb-4">
                  <div className="w-24 h-24 mx-auto mb-4 rounded-full overflow-hidden">
                    <img
                      src={member.image || "/placeholder.svg"}
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardTitle className="text-xl font-semibold">{member.name}</CardTitle>
                  <CardDescription className="text-primary font-medium">{member.specialty}</CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground mb-4">
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span>{member.rating}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      <span>{member.experience}</span>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="w-full bg-transparent" asChild>
                    <Link href="/booking">Book with {member.name.split(" ")[0]}</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
                <Calendar className="h-8 w-8 text-primary" />
              </div>
              <h4 className="text-xl font-semibold mb-2">Easy Booking</h4>
              <p className="text-muted-foreground">Book appointments online 24/7 with our simple booking system</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
                <Sparkles className="h-8 w-8 text-primary" />
              </div>
              <h4 className="text-xl font-semibold mb-2">Premium Quality</h4>
              <p className="text-muted-foreground">
                High-quality products and professional techniques for best results
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <h4 className="text-xl font-semibold mb-2">Expert Staff</h4>
              <p className="text-muted-foreground">Experienced professionals trained in latest grooming techniques</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-3xl md:text-4xl font-serif font-bold mb-4">Ready for Your Next Look?</h3>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Book your appointment today and experience the MANZONE difference
          </p>
          <Button size="lg" variant="secondary" className="text-lg px-8" asChild>
            <Link href="/booking">
              <Calendar className="mr-2 h-5 w-5" />
              Book Now
            </Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  )
}
