"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Calendar, Clock, Phone, Mail, Edit, CreditCard, History } from "lucide-react"
import { Header } from "@/components/navigation/header"

export default function ProfilePage() {
  const [user] = useState({
    name: "John Doe",
    email: "john.doe@email.com",
    phone: "+91 98765 43210",
    joinDate: "March 2024",
    totalBookings: 12,
    walletBalance: 500,
  })

  const [bookings] = useState([
    {
      id: 1,
      service: "Premium Haircut",
      staff: "Rajesh Kumar",
      date: "2024-01-15",
      time: "2:00 PM",
      status: "completed",
      amount: 800,
    },
    {
      id: 2,
      service: "Beard Styling",
      staff: "Amit Singh",
      date: "2024-01-22",
      time: "4:30 PM",
      status: "upcoming",
      amount: 500,
    },
    {
      id: 3,
      service: "Complete Grooming",
      staff: "Vikram Sharma",
      date: "2024-01-08",
      time: "11:00 AM",
      status: "completed",
      amount: 2000,
    },
  ])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "upcoming":
        return "bg-blue-100 text-blue-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Profile Header */}
          <Card className="mb-8">
            <CardHeader>
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src="/placeholder.svg" />
                  <AvatarFallback className="text-lg font-semibold">
                    {user.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <CardTitle className="text-2xl">{user.name}</CardTitle>
                  <CardDescription className="flex items-center gap-4 mt-2">
                    <span className="flex items-center gap-1">
                      <Mail className="h-4 w-4" />
                      {user.email}
                    </span>
                    <span className="flex items-center gap-1">
                      <Phone className="h-4 w-4" />
                      {user.phone}
                    </span>
                  </CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Profile
                </Button>
              </div>
            </CardHeader>
          </Card>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Total Bookings</CardDescription>
                <CardTitle className="text-3xl">{user.totalBookings}</CardTitle>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Member Since</CardDescription>
                <CardTitle className="text-3xl">{user.joinDate}</CardTitle>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Wallet Balance</CardDescription>
                <CardTitle className="text-3xl text-primary">₹{user.walletBalance}</CardTitle>
              </CardHeader>
            </Card>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="bookings" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="bookings">My Bookings</TabsTrigger>
              <TabsTrigger value="wallet">Wallet & Payments</TabsTrigger>
            </TabsList>

            <TabsContent value="bookings" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold">Booking History</h3>
                <Button>
                  <Calendar className="h-4 w-4 mr-2" />
                  New Booking
                </Button>
              </div>

              <div className="space-y-4">
                {bookings.map((booking) => (
                  <Card key={booking.id}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center gap-3">
                            <h4 className="font-semibold">{booking.service}</h4>
                            <Badge className={getStatusColor(booking.status)}>{booking.status}</Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Calendar className="h-4 w-4" />
                              {booking.date}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              {booking.time}
                            </span>
                            <span>with {booking.staff}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-semibold">₹{booking.amount}</div>
                          {booking.status === "upcoming" && (
                            <div className="flex gap-2 mt-2">
                              <Button variant="outline" size="sm">
                                Reschedule
                              </Button>
                              <Button variant="destructive" size="sm">
                                Cancel
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="wallet" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold">Wallet & Transactions</h3>
                <Button>
                  <CreditCard className="h-4 w-4 mr-2" />
                  Add Money
                </Button>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Current Balance</CardTitle>
                  <CardDescription>Available wallet balance</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold text-primary">₹{user.walletBalance}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <History className="h-5 w-5" />
                    Recent Transactions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between py-2 border-b">
                    <div>
                      <div className="font-medium">Payment for Premium Haircut</div>
                      <div className="text-sm text-muted-foreground">Jan 15, 2024</div>
                    </div>
                    <div className="text-red-600 font-medium">-₹800</div>
                  </div>
                  <div className="flex items-center justify-between py-2 border-b">
                    <div>
                      <div className="font-medium">Wallet Top-up</div>
                      <div className="text-sm text-muted-foreground">Jan 10, 2024</div>
                    </div>
                    <div className="text-green-600 font-medium">+₹1000</div>
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <div>
                      <div className="font-medium">Payment for Complete Grooming</div>
                      <div className="text-sm text-muted-foreground">Jan 8, 2024</div>
                    </div>
                    <div className="text-red-600 font-medium">-₹2000</div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
